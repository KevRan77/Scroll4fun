# Scroll4fun
Really simple item management website


# Descriptif

Projet de 4ème année en WEB réalisé par Nora Rémy et Kevin Ranaivo. Scroll4fun est un site web ayant pour vocation le partage d'images drôles à l'ensemble de la communauté du net.


-----------------------------------------------------------------------------------------------------------------------------
# Accès au site web

Pour accéder au site web, il faut entrer dans l'url de votre navigateur l'adresse suivante : 82.236.131.8:8082

-----------------------------------------------------------------------------------------------------------------------------


# Fonctionnalités

 Plusieurs fonctionnalités y sont présentes :

- L'ajout d'images : 

Vous pouvez ajouter votre propre image en cliquant sur "Ajouter". Vous aurez donc à référencier : le nom de l'image, le thème de l'image ainsi que le fichier.

- La suppression d'images:

Vous pouvez supprimer une image en cliquant sur l'icône représentée par une corbeille.

- La modification d'images:

Vous pouvez modifier une image en cliquant sur le bouton modifier. Vous aurez donc à référencier : le nom de l'image, le thème de l'image ainsi que le fichier.

- Visualisation d'une image :

Vous pouvez visualiser qu'une seule image en cliquant sur cette dernière.

- Visualisation de l'ensemble des images :

Vous pouvez visualiser l'ensemble des images en cliquant sur "Accueil".

- Visualisation des thèmes :

Vous pouvez afficher l'ensemble des thèmes du site en cliquant sur "Thèmes"
